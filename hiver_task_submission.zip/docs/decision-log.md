# Decision Log — Hiver SDE Intern Assignment
# Apple Support Twitter AI Agent

---

## D1 — Chose AppleSupport as the target brand
**Decision**: Filter the 2.8M tweet dataset to AppleSupport only.
**Why**: AppleSupport has the highest tweet volume (106k+ replies) among all brands, giving us rich data. Their support conversations cluster around a small set of technical issues (iOS, battery, apps) making intent taxonomy cleaner. Apple Support has also been used in prior research on this dataset, so it is a defensible choice.
**Alternatives considered**: AmazonHelp (highest volume but very broad — orders, returns, products, third-party sellers — too many intents), SpotifyCares (too narrow).

---

## D2 — Used both pointer directions for thread filtering
**Decision**: Collect Apple-related tweets by BFS in both directions — upward via `in_response_to_tweet_id` and downward via `response_tweet_id` — starting from every Apple reply tweet.
**Why**: The naive approach (find Apple replies → find their direct parents) only captures one level in each direction. Multi-turn threads like `customer → Apple → customer → Apple → customer` would lose the later turns.
**What changed**: v1 used a simple union of Apple reply IDs + their direct parent IDs. v2 uses full BFS expansion. Result: Apple-related tweets went from 213k (v1) to 238k (v2).

---

## D3 — Redefined "local root" to handle missing parents
**Decision**: A root tweet is one whose parent is either NaN OR not present in our filtered dataset — not just NaN.
**Why**: The dataset is a snapshot. Many threads start mid-conversation because the true root tweet was not captured. If we only find NaN parents as roots, we miss threads where the oldest tweet in our data still has a parent ID that points outside our dataset. This was flagged by the reviewer as a bug in v1.
**Impact**: Local roots found went from 74,613 (v1) to 80,717 (v2).

---

## D4 — Handled comma-separated response_tweet_id properly
**Decision**: Parse `response_tweet_id` as a comma-separated list of integers, not a single value.
**Why**: The official dataset documentation states this field can contain multiple IDs when one tweet received multiple replies. v1 was splitting on comma and taking the first value only — silently dropping branching replies.
**How we handle forks**: At a branch point (multiple children), we follow the longest branch using `get_subtree_depth()`. Rationale: support conversations are linear; branches usually happen when multiple users pile onto the same tweet. The longest branch is almost always the main resolution thread.

---

## D5 — Dropped empty turns after cleaning
**Decision**: After cleaning a tweet's text (removing @mentions and URLs), if the result is an empty string, skip that turn entirely.
**Why**: Some tweets contain only `@mention https://t.co/xyz` — nothing else. After cleaning, they become empty strings. An empty turn carries no information for classification, reply drafting, or evaluation. Keeping them created consecutive same-role turns and confused thread structure.
**Seen in**: Thread 700 had a `[CUSTOMER]` turn that was just a URL — after cleaning it was empty, producing `[CUSTOMER][CUSTOMER][BRAND]` pattern.

---

## D6 — Merged consecutive same-role turns
**Decision**: When two consecutive turns have the same role (both customer or both brand), merge their text into one turn.
**Why**: Two situations produce this pattern:
  - Another user replied to the original customer (piling on), producing `customer → customer → brand`
  - Brand sent a 2-part tweet (1/2 then 2/2), producing `brand → brand`
In both cases the correct representation is one logical turn. Keeping them separate would confuse the classifier and reply drafter.
**Trade-off**: We lose the information that it was two separate tweets, but gain a clean alternating structure that every downstream component can rely on.

---

## D7 — Chose 7 intents, not more or fewer
**Decision**: Define exactly 7 intents for the Apple Support agent.
**Why this number**: Intents were defined at the granularity where two messages in the same bucket would receive meaningfully similar replies. Tested against real data — battery complaints get the same troubleshooting flow, iOS update complaints get the same "DM us your iOS version" response. Going finer (e.g. splitting `battery_drain` into `battery_drain_after_update` and `battery_drain_normal`) created overlapping boundaries that would hurt classifier consistency and thin out eval buckets.
**Why not fewer**: 3–4 intents are too broad — "my screen is cracked" and "my keyboard types wrong" would share a label but Apple replies completely differently to each.
**The 7 intents**: ios_update_issue, battery_drain, device_hardware_issue, app_issue, account_access, order_purchase, general_inquiry.

---

## D8 — Did NOT bulk-label all 80k records with an API
**Decision**: We do not pre-classify all 80,491 threads using an LLM API.
**Why**: 
  1. Expensive — 80k API calls at even $0.001 each = $80+
  2. Circular — using an LLM to label data you then use to evaluate the same LLM
  3. Unnecessary — the retrieval pool is searched by keyword at runtime, not by label
**What we do instead**: Keyword-based stratified sampling to find 250 candidates for manual labelling. The LLM classifies only at runtime, one message at a time.

---

## D9 — Used keyword-based stratified sampling for the eval set
**Decision**: Sample 250 threads for manual labelling using keyword search, ~35 per intent bucket.
**Why stratified**: If we sampled randomly from 80k threads, the eval set would mirror the natural distribution — which is heavily skewed toward ios_update_issue (Oct 2017, iOS 11 just launched). We would end up with 150+ update complaints and 5 order questions. A stratified sample ensures every intent has enough examples to measure accuracy meaningfully.
**Why keywords for sampling**: Keywords are instant and free. They don't need to be perfect — they just need to find plausible candidates for each intent. You (the human) make the final label call.
**Labelling rules defined upfront**:
  - Battery + update in same message → ios_update_issue (update is the cause)
  - Very short or vague → general_inquiry
  - When unsure → pick the problem the customer seems most upset about

---

## D10 — Chose 250 hand-labelled examples (not 150 or 200)
**Decision**: Target 250 examples for the golden eval set, which is the upper bound the assignment allows (150–250).
**Why the upper bound**: More examples = more reliable accuracy estimates. With only 150 examples and 7 intents, some intents might have as few as 15 test cases — not enough to trust a 60% accuracy number. With 250 (35 per intent), each intent's accuracy estimate is more stable.
**Trade-off**: Takes longer to label (~2.5 hours vs ~1.5 hours for 150).

---

## D11 — Used few-shot prompting instead of training an ML model
**Decision**: Runtime classification uses an LLM with 5 few-shot examples per intent in the prompt, not a trained ML classifier.
**Why not ML**: A fine-tuned BERT or logistic regression classifier would need thousands of labelled training examples (we have 250), training time, and retraining whenever intents change. For 7 well-defined natural language intents, an LLM with good examples outperforms a small trained model with no extra cost.
**ML is used as a baseline**: TF-IDF + logistic regression trained on our 200 labelled examples (holding out 50 for test) serves as the "simple baseline" the assignment requires. This gives a real number to beat.
**Two baselines in the report**:
  - Trivial: keyword matching (same keywords used for sampling)
  - Simple: TF-IDF + logistic regression on the labelled set

---

## D12 — Retrieval pool searched by keyword_hint, not by embedding similarity
**Decision**: When the agent needs historical examples to ground its reply, it filters the retrieval pool by `keyword_hint` (same keyword logic used in sampling) rather than semantic embedding similarity.
**Why**: Embedding similarity requires running all 80k messages through an embedding model, storing vectors, and doing approximate nearest-neighbour search. That is significant infrastructure for marginal gain on this dataset — because the intents are distinct enough that keyword filtering already retrieves highly relevant threads.
**Trade-off logged**: Embedding retrieval would handle edge cases better (a message about "phone gets hot" would semantically match battery threads even though it doesn't contain the keyword "battery"). This is a known failure mode documented in the report.
**What we'd do with one more week**: Replace keyword retrieval with embedding-based retrieval using a lightweight model like `sentence-transformers/all-MiniLM-L6-v2`.

---

## D13 — Refined keywords after analysing 100 real messages + added spot-check
**Decision**: After sampling and reading 100 real customer messages, we updated two intent keyword lists. We also added a mandatory keyword accuracy spot-check (10 messages × 7 intents = 70 messages) before committing to the eval set.
**What the 100-message analysis found**:
  - The iOS 11 "I️ → A?" autocorrect bug was ~15% of all messages but used no standard keywords — customers said "question mark", "boxes", "letter I", "I️". These were silently falling into general_inquiry. Fixed by adding those terms to ios_update_issue keywords.
  - Several account_access messages matched app_issue keywords (iCloud, unlock, iTunes). Fixed by moving "icloud", "unlock", "icloud storage" to account_access keywords.
  - ios_update_issue is heavily dominant (~44% of messages) because this data is from Oct/Nov 2017 — right when iOS 11 launched and was notoriously buggy.
**Why a spot-check**:
  Keywords can be wrong. Without measuring accuracy we cannot claim the sampling is representative. 70 messages × ~15 seconds = ~17 minutes to produce a number we can quote in the report and defend in the interview.
**Expected finding**: keyword accuracy should be 80–90% for most intents. general_inquiry will be lower by design — it is a catch-all for messages that matched no keyword, so some will genuinely belong to specific intents.
**Where this appears in the report**: "What is misleading about my headline number?" — keyword sampling bias means the eval set may slightly over-represent clear-cut cases (messages with obvious keywords) and under-represent ambiguous ones.

---

## D14 — Parallelized Escalator and Reply Drafting
**Decision**: Used `concurrent.futures.ThreadPoolExecutor` in `pipeline.py` to run the Escalator check and the (Retriever + Reply Drafter) chain in parallel.
**Why**: Both steps require an LLM API call, which is entirely network-bound. The Escalator only needs the `intent` (from the classifier), meaning it does not need to wait for the Reply Drafter to finish. By running them concurrently, we effectively hide the latency of the Escalator call behind the Drafter call, saving ~1–2 seconds per message on the pipeline's overall execution time.

---

*(D13 updated with measured results after human labelling)*

**Measured keyword accuracy** (245 examples, human verified):
- Overall: 166/245 = 67.8%
- ios_update_issue: 33/35 = 94% ← strong
- battery_drain: 28/35 = 80%
- account_access: 27/35 = 77%
- order_purchase: 22/35 = 63%
- device_hardware_issue: 19/35 = 54%
- general_inquiry: 20/35 = 57% (catch-all, expected)
- app_issue: 17/35 = 49% ← weakest, keywords too broad

**What the 32.2% override rate revealed**:
- app_issue keywords too broad — "mail", "music", "app" matched account_access and device issues
- order_purchase matched iPhone X complaints that were general_inquiry
- device_hardware_issue matched "keyboard bug" messages that were actually ios_update_issue
- general_inquiry caught ios_update_issue messages with informal language ("fix this software", "boxes")

**Why 67.8% is still acceptable**: All 245 labels were human-verified. The keyword errors affected sampling source, not final label. Ground truth is the human label. The override rate is documented evidence, not a hidden flaw.




D14 — Parallelized escalator and reply drafting

Decision: concurrent.futures.ThreadPoolExecutor runs escalator and drafter in parallel. Why: Both are network-bound API calls. Escalator only needs intent — does not wait for drafter. Saves ~1–2 seconds per message.

D15 — llm_factory.py for swappable LLM providers

Decision: Single generate_completion() function supports Groq, Ollama, OpenAI-compatible APIs via .env. Why: Free-tier Groq hits rate limits quickly on bulk eval. Ollama allows local inference with no rate limits. Switching providers requires no agent code changes.

D16 — ComplementNB + Keywords as simple baseline

Decision: Simple baseline = ComplementNB with 7 binary keyword features added via FeatureUnion. Why not plain TF-IDF: Plain ComplementNB: 48.6% CV — below keyword baseline. Genuine finding: 28 training examples is insufficient for TF-IDF. Why keyword augmentation: Gives the model domain knowledge it cannot discover from 28 examples.

order_purchase F1: 0.0 → 0.571 (complete recovery)
battery_drain recall: hit 1.0 (perfect) Final numbers: Plain ML 48.6% → ML+Keywords 60.0% → Keyword 67.8% → LLM TBD. Unexpected ordering: keyword > plain ML. Documented as genuine finding motivating the LLM approach.
D17 — Stratified train/test split for ML baseline

Decision: StratifiedShuffleSplit instead of random shuffle for ML baseline. Why: Random split put too many of one intent in test, too few in training. Original random split produced 30.6% — an artifact. Stratified split guarantees proportional representation. Impact: TF-IDF accuracy went from 30.6% (artifact) to 51.0% (fair measurement).

══════════════════════════════════════════════
FAILURE ANALYSIS — Top 5 failure modes
══════════════════════════════════════════════
Failure 1 — app_issue / account_access boundary confusion

Evidence:

Message: "can't log into Game Center and this msg keeps coming up. What does it mean?"
True label:      app_issue
Agent predicted: account_access

Also seen across ML baselines — both LinearSVC and ComplementNB confuse these two intents.

Why: "log into", "can't sign in", "account" are strong account_access signals. The LLM routes to account_access on authentication language. But Game Center login failures are app-level — Apple's fix is reinstall or update the app, not reset an Apple ID.

Hypothesis: The boundary is genuinely ambiguous. A Game Center login failure could be an app bug OR an account issue. The intent definition needs a sharper rule: "if the problem disappears when you reinstall the app → app_issue; if it persists across reinstalls → account_access."

Impact: Medium. Both replies end with "DM us" — customer is still helped, but next step is slightly wrong.

Failure 2 — general_inquiry is a black hole

Evidence:

"fix this please"          → general_inquiry (correct, but unhelpful)
"my phone is broken"       → general_inquiry (should be device_hardware_issue)
"boxes everywhere"         → general_inquiry (should be ios_update_issue — the I️ bug)

general_inquiry F1 = 0.167 in the best ML model. Worst class across every model tested.

Why: general_inquiry is defined by the ABSENCE of specific keywords. TF-IDF cannot learn absence. The LLM handles this better but still struggles with messages too short to provide semantic signal.

Hypothesis: The intent is doing two jobs: (1) genuinely ambiguous messages and (2) clearly specific intents expressed informally. These need to be separated. With more time, we would add informal synonyms to every intent's keyword list ("dying", "dead" for battery; "busted", "wrecked" for hardware).

Impact: High. general_inquiry is ~20% of traffic. Every mis-routed message here gets a generic reply.

Failure 3 — Generic fallback replies (retrieval failure)

Evidence:

Message: "How can I prevent my iPhone7 from dying during cold weather runs?"
Reply:   "We're sorry to hear you're having trouble. Please DM us with more details..."

Message: "2) If I made a mistake in my information, will it cancel my reservation?"
Reply:   "We're sorry to hear you're having trouble. Please DM us with more details..."

3 out of 10 agent replies in the sample were the hardcoded fallback string.

Why: Two causes:

The LLM returned an empty or very short string triggering the fallback safety check
The retrieved threads themselves had only generic brand replies ("DM us") — the model had nothing specific to ground its reply in

Hypothesis: The retrieval pool contains many threads where Apple's reply was itself generic. When all 3 retrieved threads say "DM us for help", the model learns that is the correct Apple reply. Fix: filter retrieval pool to exclude threads where ALL brand replies are shorter than 50 characters or contain only DM variants.

Impact: High for trust. A fallback reply is indistinguishable from a broken system.

Failure 4 — Temporal distribution shift (iOS 11 period bias)

Evidence:

Dataset: October/November 2017 — iOS 11 launch
ios_update_issue: 53% of all messages
battery_drain:     5% of all messages

During this period: "battery", "slow", "crash" almost always appeared in iOS 11 complaints.
The model learned: these words → ios_update_issue.
Outside this period: these words → probably battery_drain or device_hardware_issue.

Why: The model was trained and evaluated on the same historical moment. The keyword and vocabulary distributions are specific to the iOS 11 launch period and would not hold for any other time.

Hypothesis: The keyword baseline is more robust to this than the LLM — "battery" always maps to battery_drain regardless of temporal context. The LLM's few-shot examples are also from this period and carry the same bias.

Impact: High for generalisability. The agent cannot be deployed to current Apple Support traffic without retraining or re-prompting with current examples.

Failure 5 — Escalation false positives from substring matching

Evidence:

Message:  "having battery issues any help? iOS 11 sucks ass"
Decision: ESCALATE — "Customer mentioned legal action — requires human agent"
True:     AUTO_HANDLE — no legal threat present

Why: Hard rule patterns use Python's in operator — simple substring matching with no word boundaries. The pattern for legal threats matched within innocent text. "sue" would match inside "tissue" or "because". Short patterns are especially vulnerable.

Fix:

python
# Current (wrong):
if "sue" in message_lower:

# Fixed:
import re
if re.search(r'\bsue\b', message_lower):

Impact: Low frequency but high cost — every false positive wastes a human agent's time. At scale this is expensive. Also breaks user trust if customers escalate for no reason.

══════════════════════════════════════════════
WHAT IS MISLEADING ABOUT THE HEADLINE NUMBER
══════════════════════════════════════════════

The headline classification accuracy overstates real-world performance in four ways:

1. Stratified eval ≠ real distribution The eval set has exactly 35 examples per intent. Real traffic is 53% ios_update_issue, 2% order_purchase. If the agent is great at ios_update_issue and terrible at order_purchase, stratified accuracy looks artificially balanced. On the natural distribution, the headline would be higher (dominant class is our easiest intent) but order_purchase and device_hardware_issue failures would be nearly invisible at 2% and 5% of traffic.

2. Keyword sampling bias The 245 examples were sampled using keyword matching (67.8% accurate). The eval set over-represents messages with clear keywords and under-represents ambiguous ones — exactly the messages the agent fails on. True accuracy on random production traffic is likely 3–5% lower than measured.

3. Single time period The data is from October/November 2017 — iOS 11 launch. Over half the messages reference bugs that no longer exist. The agent was trained and evaluated on the same historical moment. It would perform significantly worse on current Apple Support traffic.

4. Classification accuracy ≠ reply quality or helpfulness A correctly classified message can still get a terrible reply. A misclassified message can get a decent generic reply. The headline measures only step 1 of a 3-step pipeline. Reply quality (judge scores) and escalation accuracy are equally important but invisible in the headline number.

══════════════════════════════════════════════
WHAT WE WOULD DO WITH ONE MORE WEEK
══════════════════════════════════════════════
Embedding-based retrieval: sentence-transformers/all-MiniLM-L6-v2 for semantic similarity. "Phone gets hot" would find battery threads without keyword match.
Fix escalation false positives: Regex word-boundary matching (\bsue\b) instead of substring in checks.
Filter retrieval pool for quality: Exclude threads where all brand replies are generic ("DM us"). Only retrieve threads with specific, actionable Apple responses.
Informal synonym expansion: Add "dying", "dead", "shot" for battery; "busted", "wrecked" for hardware; to reduce general_inquiry black hole.
Human-judge agreement: Score 30 agent replies manually and compute Pearson correlation with LLM judge. Currently missing from eval harness.
Run full eval on all 245 examples: Currently only 10 have been evaluated. Full run gives reliable per-intent accuracy and escalation rate.
Fix escalation substring matching (critical — do this first): regex word boundaries on all hard rule patterns.